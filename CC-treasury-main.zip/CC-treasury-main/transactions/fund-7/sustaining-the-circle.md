# Sustaining the Circle

Hold shift and scroll on table for sideway scrolling

| Date       | Member        | Role         | Amount | Description         | Comments |
| ---------- | ------------- | ------------ | ------ | ------------------- | -------- |
| 2022-01-07 | André Diamond | CC Treasurer | 200    | Server Hosting Fees |          |
| 2022-01-11 | Miroslav Rajh | CC Treasurer | 200    |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
|            |               |              |        |                     |          |
