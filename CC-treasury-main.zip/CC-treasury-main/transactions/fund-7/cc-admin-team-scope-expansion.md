# CC Admin Team Scope Expansion

| Date | Name | CC Admin role | Share Points | Amount |   |
| ---- | ---- | ------------- | ------------ | ------ | - |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
|      |      |               |              |        |   |
